import RPi.GPIO as GPIO
import time


a=0
while a <10:
       ticks = time.time()
       print ("Number of ticks since 12:00am, January 1, 1970: ", ticks)
       a += 1



'''
GPIO.setwarnings(False)
GPIO.setmode(GPIO.BOARD)
GPIO.setup(10, GPIO.IN)

while True:
       i=GPIO.input(10)
       if i==0:                 #When output from motion sensor is LOW
             print ("No intruders",i)
             time.sleep(0.1)
             
       elif i==1:               #When output from motion sensor is HIGH
             print ("AHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHHH\n\n")
             time.sleep(0.1)
'''
